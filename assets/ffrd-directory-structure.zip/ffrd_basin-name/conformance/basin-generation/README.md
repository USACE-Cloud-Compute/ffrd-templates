# basin-generation

The basin-generation subdirectory is populated with:

* A copy of the DSS output file from the HMS PoR run from the calibration phase.
* The *.basin and *.control files from each of the calibration events from the calibration phase (typically 6 events).

These files are used by the basin-record-gen-plugin cloud compute actions to build combinations to represent the variation in antecedent conditions for stochastic simulations.