# project-scoping
Folder includes key inputs that define the scope of the study, created during the Scoping and Data Preparation Phase. **Refer to the FFRD Standard Operating Procedure (SOP) document** for official guidance on project scoping.

Several subfolders are used to define this scoping, which include:

## calibration-scope
Includes:

* Geospatial file containing locations of primary, secondary, and tertiary stream gage locations

* Calibration Event Table: Tabulation of historic events selected for calibration

## dam-scoping-table 
Inclusion for operations modeling, inclusion for fragility, and criteria for how a dam is modeled.

## hydraulic-model-units
Polygons defining the scoped boundaries of individual hydraulic models.

## levee-modeling-scope
Levee breach location geospatial file. Progresses from draft during scoping and data preparation phase to final during subsequent phases.

## mesh-development-criteria
Designated key streams, other streams and urban areas that define the scope for mesh development according to the hydraulics section of FFRD SOP.

## model-linking-register
Model linking register for the project that clearly shows the source of all required inputs for each model. Includes a version for the calibration phase (when observed flows for historic events are commonly used as inputs) and for the conformance phase (when all inputs are based on modeled outputs).

## name-table
Tables that pre-define key model element names for the study that is developed during the Scoping and Data Preparation Phase.

## study-area-polygon
Polygon defining the study area for the project.

## uncalibrated-hydrologic-model 
Uncalibrated hydrologic model that includes all planned HMS model elements, including subbasins established during scoping and data preparation phase of the FFRD project.
